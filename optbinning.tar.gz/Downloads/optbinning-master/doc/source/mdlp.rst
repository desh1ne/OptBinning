MDLP discretization algorithm
=============================

.. autoclass:: optbinning.MDLP
   :members:
   :inherited-members:
   :show-inheritance:
