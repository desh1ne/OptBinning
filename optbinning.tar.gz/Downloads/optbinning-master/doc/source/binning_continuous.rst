Optimal binning with continuous target
======================================

.. autoclass:: optbinning.ContinuousOptimalBinning
   :members:
   :inherited-members:
   :show-inheritance:
