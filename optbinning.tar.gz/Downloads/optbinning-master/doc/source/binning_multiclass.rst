Optimal binning with multiclass target
======================================


.. autoclass:: optbinning.MulticlassOptimalBinning
   :members:
   :inherited-members:
   :show-inheritance: