Outlier detection
=================

.. autoclass:: optbinning.outlier.OutlierDetector
   :members:
   :inherited-members:
   :show-inheritance:


.. autoclass:: optbinning.outlier.RangeDetector
   :members:
   :inherited-members:
   :show-inheritance:


.. autoclass:: optbinning.outlier.ModifiedZScoreDetector
   :members:
   :inherited-members:
   :show-inheritance:
