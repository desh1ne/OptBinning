Binning tables
==============

Binning table: binary target
----------------------------

.. autoclass:: optbinning.binning.binning_statistics.BinningTable
   :members:
   :inherited-members:
   :show-inheritance:

Binning table: continuous target
--------------------------------

.. autoclass:: optbinning.binning.binning_statistics.ContinuousBinningTable
   :members:
   :inherited-members:
   :show-inheritance:

Binning table: multiclass target
--------------------------------

.. autoclass:: optbinning.binning.binning_statistics.MulticlassBinningTable
   :members:
   :inherited-members:
   :show-inheritance:   