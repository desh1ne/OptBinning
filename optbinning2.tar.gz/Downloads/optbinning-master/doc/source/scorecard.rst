Scorecard
=========

.. autoclass:: optbinning.scorecard.Scorecard
   :members:
   :inherited-members:
   :show-inheritance:


Plot functions
--------------

.. autofunction:: optbinning.scorecard.plot_auc_roc

.. autofunction:: optbinning.scorecard.plot_cap

.. autofunction:: optbinning.scorecard.plot_ks